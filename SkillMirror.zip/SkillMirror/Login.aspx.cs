﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SkillMirror
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            bool loginExitoso = true; // Reemplaza esto con tu lógica real

            if (loginExitoso)
            {
                // ¡Paso Clave! Guardamos el nombre del usuario en la Sesión.
                // Podrías guardar el nombre, el email, el ID, o un objeto completo.
                Session["UserName"] = txtEmail.Text; // Usamos el email como ejemplo

                // Redirigimos al usuario a la página principal o su panel.
                System.Web.Security.FormsAuthentication.RedirectFromLoginPage(txtEmail.Text, false);

                Response.Redirect(Page.ResolveUrl("~/Default.aspx"));
            }
            else
            {
                // Muestra un mensaje de error si el login falla.
                litErrorMessage.Text = "<div class='alert alert-danger'>Usuario o contraseña incorrectos.</div>";
            }
        }

    }
}