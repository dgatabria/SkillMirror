﻿<%-- Registro.aspx (con Aceptación de Términos) --%>
<%@ Page Title="Registro" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Registro.aspx.cs" Inherits="SkillMirror.Registro" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .registration-container { display: flex; align-items: center; justify-content: center; padding: 2rem 0; }
        .registration-card { max-width: 600px; width: 100%; }
        .card-header { background-color: var(--primary-color); color: white; text-align: center; }
        .btn-register-submit { background-color: var(--primary-color); border-color: var(--primary-color); width: 100%; padding: 10px; font-size: 1.1rem; }
        .btn-register-submit:hover { background-color: #006666; border-color: #006666; }
        .g-recaptcha { margin-top: 1rem; transform: scale(1.05); transform-origin: center; }
    </style>

    <div class="registration-container">
        <div class="card registration-card shadow-lg">
            <div class="card-header"><h3>Crear una Cuenta</h3></div>
            <div class="card-body p-4">
                <asp:ValidationSummary runat="server" ForeColor="Red" CssClass="mb-3" />
                <div class="row">
                    <%-- Campos de Nombre y Apellido --%>
                </div>
                <%-- Campos de DNI y Email --%>
                <div class="row">
                    <%-- Campos de Contraseña y Confirmación --%>
                </div>

                <%-- Contenedor de reCAPTCHA --%>
                <div class="d-flex justify-content-center g-recaptcha">
                    <div data-sitekey="AQUÍ_VA_TU_CLAVE_DEL_SITIO"></div>
                </div>
                <asp:Label ID="lblRecaptchaError" runat="server" ForeColor="Red" CssClass="d-block text-center mt-2 mb-3"></asp:Label>

                <%-- ### NUEVA SECCIÓN: TÉRMINOS Y CONDICIONES ### --%>
                <div class="form-check mt-3">
                    <asp:CheckBox ID="chkAceptoTerminos" runat="server" CssClass="form-check-input" />
                    <label class="form-check-label" for="<%= chkAceptoTerminos.ClientID %>">
                        He leído y acepto los 
                        <a href="<%= Page.ResolveUrl("~/TerminosYCondiciones.aspx") %>" target="_blank">Términos y Condiciones</a>.
                    </label>
                    <asp:CustomValidator 
                        ID="TerminosValidator" 
                        runat="server" 
                        ErrorMessage="Debe aceptar los términos y condiciones para registrarse." 
                        ForeColor="Red" 
                        Display="Dynamic" 
                        OnServerValidate="Terminos_ServerValidate"
                        CssClass="d-block mt-1">
                    </asp:CustomValidator>
                </div>
                
                <div class="d-grid mt-4">
                    <asp:Button ID="btnRegister" runat="server" Text="Registrarse" CssClass="btn btn-primary btn-register-submit" OnClick="BtnRegister_Click" />
                </div>
            </div>
            <div class="card-footer text-center">
                 <small>¿Ya tienes una cuenta? <a href="<%= Page.ResolveUrl("~/Login.aspx") %>">Inicia Sesión</a></small>
            </div>
        </div>
    </div>

    <%-- ### NUEVO SCRIPT: Habilitar/Deshabilitar Botón ### --%>
    <script type="text/javascript">
        // Se ejecuta cuando el DOM está completamente cargado
        document.addEventListener("DOMContentLoaded", function () {
            const chkTerminos = document.getElementById('<%= chkAceptoTerminos.ClientID %>');
            const btnRegistro = document.getElementById('<%= btnRegister.ClientID %>');

            // Función para actualizar el estado del botón
            function toggleButtonState() {
                btnRegistro.disabled = !chkTerminos.checked;
            }

            // Llama a la función al cargar la página para establecer el estado inicial
            toggleButtonState();

            // Agrega un listener al checkbox para que llame a la función cada vez que cambie
            chkTerminos.addEventListener('change', toggleButtonState);
        });
    </script>
</asp:Content>