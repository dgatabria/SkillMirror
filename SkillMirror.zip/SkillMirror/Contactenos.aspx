﻿<%-- Contactenos.aspx --%>
<%@ Page Title="Contáctenos" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Contactenos.aspx.cs" Inherits="SkillMirror.Contactenos" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

    <div class="page-header">
        <h1>Contacto</h1>
        <p class="lead">Estamos aquí para ayudarte. Envíanos tu consulta.</p>
    </div>

    <div class="row">
        <%-- Formulario de Contacto --%>
        <div class="col-lg-7 mb-4 mb-lg-0">
            <h3>Envíanos un Mensaje</h3>
            <div class="mb-3">
                <label for="txtName" class="form-label">Nombre Completo</label>
                <asp:TextBox ID="txtName" runat="server" CssClass="form-control" required="required"></asp:TextBox>
            </div>
            <div class="mb-3">
                <label for="txtEmail" class="form-label">Correo Electrónico</label>
                <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" TextMode="Email" required="required"></asp:TextBox>
            </div>
            <div class="mb-3">
                <label for="txtSubject" class="form-label">Asunto</label>
                <asp:TextBox ID="txtSubject" runat="server" CssClass="form-control" required="required"></asp:TextBox>
            </div>
            <div class="mb-3">
                <label for="txtMessage" class="form-label">Mensaje</label>
                <asp:TextBox ID="txtMessage" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="5" required="required"></asp:TextBox>
            </div>
            <asp:Button ID="btnSend" runat="server" Text="Enviar Mensaje" CssClass="btn btn-primary" />
        </div>

        <%-- Información de Contacto --%>
        <div class="col-lg-5">
            <h3>Información de la Empresa</h3>
            <p>
                Ponte en contacto con nosotros a través de los siguientes canales o visítanos en nuestra oficina.
            </p>
            <ul class="list-unstyled">
                <li class="mb-3">
                    <strong>Dirección:</strong> Av. de Mayo 1234, C1085 CABA, Argentina
                </li>
                <li class="mb-3">
                    <strong>Teléfono:</strong> +54 11 5555-2025
                </li>
                <li class="mb-3">
                    <strong>Email:</strong> contacto@skillmirror.com.ar
                </li>
                 <li class="mb-3">
                    <strong>Horario:</strong> Lunes a Viernes, 9:00 - 18:00 hs.
                </li>
            </ul>
        </div>
    </div>

</asp:Content>